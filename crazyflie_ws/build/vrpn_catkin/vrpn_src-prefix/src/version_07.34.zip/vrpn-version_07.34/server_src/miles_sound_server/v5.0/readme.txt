 Should copy sound_server.exe to c:\miles_sound_server. Might need to
make this directory if it doesn't exist. Also project expects Miles stuff
to be at c:\miles.