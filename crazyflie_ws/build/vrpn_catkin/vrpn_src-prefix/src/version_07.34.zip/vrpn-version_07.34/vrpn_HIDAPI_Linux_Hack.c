// This is here to get the correct .c file.

#include "submodules/hidapi/libusb/hid.c"
